@extends('layouts.application')
@section('content')
    <div class="card-body">
        <span class="card-title text-danger">
         <h3>ملاحظات فى غاية الاهمية </h3>
        </span>
        <hr>
        <ul class="list-group">
            <li class="list-group-item list-group-item-light">يشترط المتقدم ان يكون سعودى يشترط المتقدم ان يكون سعودى يشترط المتقدم ان يكون سعودى يشترط المتقدم ان يكون سعودى</li>
            <li class="list-group-item list-group-item-light">يشترط المتقدم ان يكون سعودى</li>
            <li class="list-group-item list-group-item-light">يشترط المتقدم ان يكون سعودى</li>
            <li class="list-group-item list-group-item-light">يشترط المتقدم ان يكون سعودى</li>
        </ul>
        <hr>
        <span class="card-title text-danger">
         <h5>ملاحظات فى غاية الاهمية </h5>
        </span>
    </div>
@endsection
