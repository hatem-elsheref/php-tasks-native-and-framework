@include('layouts.shared.header')
@include('layouts.shared.sidebar')
@include('sweetalert::alert')
@yield('content')
@include('layouts.shared.setting-sidebar')
@include('layouts.shared.footer')


