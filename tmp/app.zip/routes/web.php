<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
*/

Auth::routes(['password.request'=>false,'reset'=>false]);

Route::group(['middleware'=>['auth:web']],function(){
    // INDEX-HOME-DEFAULT PAGE
    Route::get('/', 'HomeController@index')->name('home');

    // Application Process
    Route::delete('/Application/Delete/{id}', 'HomeController@destroy')->name('application.destroy');
    Route::post('/Application/Accept/{id}', 'HomeController@accept')->name('application.status.accept');
    Route::post('/Application/Refuse/{id}', 'HomeController@refuse')->name('application.status.refuse');

    // USER PROFILE
    Route::get('/My-Account','AccountController@showAccount')->name('my-account.show');
    Route::put('/Update-Account-Info','AccountController@updateInformation')->name('my-account.update');
    Route::put('/Reset-Account-Password','AccountController@resetPassword')->name('my-account.reset');

    //STUDIES OPERATION
    Route::get('/Studies','StudiesController@index')->name('studies.index');
    Route::get('/Studies/Create','StudiesController@create')->name('studies.create');
    Route::post('/Studies/Create','StudiesController@store')->name('studies.store');


});




