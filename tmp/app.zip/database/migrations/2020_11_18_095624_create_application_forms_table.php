<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateApplicationFormsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('application_forms', function (Blueprint $table) {
            $table->id();
            $table->string('university')->nullable();
            $table->string('department');
            $table->year('graduation');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('study_id'); // programming / math / etc..
            $table->unsignedBigInteger('country_id');
            $table->enum('status',['approved','canceled','pending'])->default('pending');
            $table->enum('study_type',['internal','external'])->default('internal');


            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('study_id')->references('id')->on('studies')->onDelete('cascade');
            $table->foreign('country_id')->references('id')->on('countries')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('application_forms');
    }
}
