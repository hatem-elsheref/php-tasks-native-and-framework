<?php

return [
    'available_studies'=>[
        [
            'name'=>'Programming',
            'alias'=>'برمجة',
        ],
        [
            'name'=>'Space',
            'alias'=>'فضاء',
        ],
        [
            'name'=>'Math',
            'alias'=>'رياضة',
        ],
        [
            'name'=>'Atom',
            'alias'=>'ذرة',
        ],
        [
            'name'=>'Art',
            'alias'=>'اداب',
        ],
    ],
    'universities'=>[
        [
            'name'=>'university_1',
            'alias'=>'جامعه 1',
        ],
        [
            'name'=>'university_2',
            'alias'=>'جامعه 2',
        ],
        [
            'name'=>'university_3',
            'alias'=>'جامعه 3',
        ],
    ],
    'types'=>[
        [
            'name'=>'internal',
            'alias'=>'منحة داخلية'
        ],
        [
            'name'=>'external',
            'alias'=>'بعثة خارجية'
        ]
    ],
    'primary_school_departments'=>[
        'علمى',
        'شرعى'
    ]
];
