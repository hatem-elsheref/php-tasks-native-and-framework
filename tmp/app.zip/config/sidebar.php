<?php

return [
    'links'=>[
       'admin'=>[
           [
               'name'  =>'dashboard',
               'icon'  =>'mdi mdi-view-dashboard-outline',
               'active'=>false,
               'sub'   =>[
                   [
                       'name'  =>'all',
                       'new'   =>false,
                       'color' =>'danger',
                       'route' =>'home'
                   ]
               ],
           ]
       ],
        'student'=>[
            [
                'name'  =>'studies',
                'icon'  =>'mdi mdi-account-edit',
                'active'=>false,
                'sub'   =>[
                    [
                        'name'  =>'studies.index',
                        'new'   =>false,
                        'color' =>'danger',
                        'route' =>'studies.index'
                    ],
                    [
                        'name'  =>'studies.create',
                        'new'   =>false,
                        'color' =>'danger',
                        'route' =>'studies.create'
                    ]
                ],
            ]

    ]
]
    ];
