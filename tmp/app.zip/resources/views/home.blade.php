@extends('layouts.master')

@section('content')
    <nav aria-label="breadcrumb" class="paths-nav">
        <ol class="breadcrumb breadcrumb-inverse">
            <li class="breadcrumb-item">
                <a href="{{route('home')}}">{{__('backend.home')}}</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">{{__('backend.statistics')}}</li>
        </ol>
    </nav>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom justify-content-between" >
                    <h2>طلبات تحت المراجعة</h2>
                </div>
                <div class="card-body">
                    <table class="table table-hover ">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">الصورة</th>
                            <th scope="col">اسم الطالب</th>
                            <th scope="col"> النوع</th>
                            <th scope="col"> البلد</th>
                            <th scope="col"> الجامعة</th>
                            <th scope="col"> الشعبة</th>
                            <th scope="col"> طلب منحة فى</th>
                            <th scope="col"> سنة التخرج</th>
                            <th scope="col">{{__('backend.control')}}</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($pending as $application)
                            <tr>
                                <td>{{$application->id}}</td>
                                <td><img src="{{uploads($application->user->avatar)}}" width="50px" height="50px" alt="{{$application->user->name}} avatar"></td>
                                <td>{{$application->user->name}}</td>
                                <td>{{$application->study_type=='internal'?'منحة داخلية':'بعثة خارجية'}}</td>
                                <td>{{$application->country->name}}</td>
                                <td>{{collect(config('menah.universities'))->pluck('alias','name')->toArray()[$application->university]??'غير محدد'}}</td>
                                <td>{{$application->department}}</td>
                                <td>{{$application->study->name}}</td>
                                <td>{{$application->graduation}}</td>
                                <td class="text-right">
                                    <button class="btn btn-sm btn-danger" onclick="document.getElementById('item-{{$application->id}}-refuse').submit()">رفض الطلب</button>
                                    <button class="btn btn-sm btn-success" onclick="document.getElementById('item-{{$application->id}}-accept').submit()">قبول الطلب</button>
                                </td>
                                <form action="{{route('application.status.accept',$application->id)}}" id="item-{{$application->id}}-accept" method="POST">@csrf</form>
                                <form action="{{route('application.status.refuse',$application->id)}}" id="item-{{$application->id}}-refuse" method="POST">@csrf</form>

                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card card-default">
                <div class="card-header card-header-border-bottom justify-content-between" >
                    <h2>طلبات مقبوله </h2>
                </div>
                <div class="card-body">
                    <table class="table table-hover ">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">الصورة</th>
                            <th scope="col">اسم الطالب</th>
                            <th scope="col"> النوع</th>
                            <th scope="col"> البلد</th>
                            <th scope="col"> الجامعة</th>
                            <th scope="col"> الشعبة</th>
                            <th scope="col"> طلب منحة فى</th>
                            <th scope="col"> سنة التخرج</th>
                            <th scope="col">{{__('backend.control')}}</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($approved as $application)
                            <tr>
                                <td>{{$application->id}}</td>
                                <td><img src="{{uploads($application->user->avatar)}}" width="50px" height="50px" alt="{{$application->user->name}} avatar"></td>
                                <td>{{$application->user->name}}</td>
                                <td>{{$application->study_type=='internal'?'منحة داخلية':'بعثة خارجية'}}</td>
                                <td>{{$application->country->name}}</td>
                                <td>{{collect(config('menah.universities'))->pluck('alias','name')->toArray()[$application->university]??'غير محدد'}}</td>
                                <td>{{$application->department}}</td>
                                <td>{{$application->study->name}}</td>
                                <td>{{$application->graduation}}</td>
                                <td class="text-right">
                                    <button class="btn btn-sm btn-danger" onclick="RemoveItem('item-{{$application->id}}')"><i class="mdi mdi-trash-can"></i></button>
                                </td>
                                <form action="{{route('application.destroy',$application->id)}}" id="item-{{$application->id}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                </form>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card card-default">
                <div class="card-header card-header-border-bottom justify-content-between" >
                    <h2>طلبات  مرفوضة</h2>
                </div>
                <div class="card-body">
                    <table class="table table-hover ">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">الصورة</th>
                            <th scope="col">اسم الطالب</th>
                            <th scope="col"> النوع</th>
                            <th scope="col"> البلد</th>
                            <th scope="col"> الجامعة</th>
                            <th scope="col"> الشعبة</th>
                            <th scope="col"> طلب منحة فى</th>
                            <th scope="col"> سنة التخرج</th>
                            <th scope="col">{{__('backend.control')}}</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($canceled as $application)
                            <tr>
                                <td>{{$application->id}}</td>
                                <td><img src="{{uploads($application->user->avatar)}}" width="50px" height="50px" alt="{{$application->user->name}} avatar"></td>
                                <td>{{$application->user->name}}</td>
                                <td>{{$application->study_type=='internal'?'منحة داخلية':'بعثة خارجية'}}</td>
                                <td>{{$application->country->name}}</td>
                                <td>{{collect(config('menah.universities'))->pluck('alias','name')->toArray()[$application->university]??'غير محدد'}}</td>
                                <td>{{$application->department}}</td>
                                <td>{{$application->study->name}}</td>
                                <td>{{$application->graduation}}</td>
                                <td class="text-right">
                                    <button class="btn btn-sm btn-danger" onclick="RemoveItem('item-{{$application->id}}')"><i class="mdi mdi-trash-can"></i></button>
                                </td>
                                <form action="{{route('application.destroy',$application->id)}}" id="item-{{$application->id}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                </form>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
