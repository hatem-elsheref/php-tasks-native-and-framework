@extends('layouts.master')

@section('content')
    <nav aria-label="breadcrumb" class="paths-nav">
        <ol class="breadcrumb breadcrumb-inverse">
            <li class="breadcrumb-item">
                <a href="{{route('home')}}">{{__('backend.home')}}</a>
            </li>
            <li class="breadcrumb-item">
                <a href="{{route('studies.index')}}">{{__('backend.studies')}}</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">{{__('backend.studies.create')}}</li>
        </ol>
    </nav>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom justify-content-between" >
                    <h2>{{__('backend.studies.create')}}</h2>
                    <a href="{{route('studies.index')}}" class="btn btn-sm btn-primary"><i class="mdi mdi-refresh"></i> {{__('backend.studies.index')}}</a>
                </div>
                <div class="card-body">
                    <form method="post" action="{{route('studies.store')}}">
                        @csrf
                        <div class="form-row">
                            <div class="col-md-4 mb-3">
                                <label for="type">نوع المنحه / البعثة</label>
                                <select name="type" id="type"   class="form-control   @error('type') is-invalid  @enderror">
                                    @foreach($studies_type as $type)
                                        <option value="{{$type['name']}}" @if(old('type') == $type['name']) selected @endif>{{$type['alias']}} </option>
                                    @endforeach
                                </select>
                                @error('type')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="country">{{__('backend.country')}}</label>
                                <select name="country" id="country"   class="form-control   @error('country') is-invalid  @enderror">
                                    <option disabled selected>{{__('backend.select')}}</option>
                                    @foreach($countries as $country)
                                        <option value="{{$country->id}}" @if(old('country') == $country->id) selected @endif>{{$country->name}}</option>
                                    @endforeach
                                </select>
                                @error('country')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="university">الجامعات</label>
                                <select name="university" id="university"   class="form-control   @error('university') is-invalid  @enderror">
                                    <option disabled selected>{{__('backend.select')}}</option>
                                    @foreach($universities as $university)
                                        <option value="{{$university['name']}}" @if(old('university') == $university['name']) selected @endif>{{$university['alias']}}</option>
                                    @endforeach
                                </select>
                                @error('university')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                                @enderror
                            </div>


                        </div>
                        <div class="form-row">
                            <div class="col-md-4 mb-3">
                                <label for="studies">{{__('backend.studies')}}</label>
                                <select name="studies" id="studies"   class="form-control   @error('studies') is-invalid  @enderror">
                                    <option disabled selected>{{__('backend.select')}}</option>
                                    @foreach($studies as $study)
                                        <option value="{{$study->id}}" @if(old('studies') == $study->id) selected @endif>{{$study->alias}}</option>
                                    @endforeach
                                </select>
                                @error('service_type')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="department">ثانوية عامة شعبة</label>
                                <select name="department" id="department"   class="form-control   @error('department') is-invalid  @enderror">
                                    <option disabled selected>{{__('backend.select')}}</option>
                                    @foreach($departments as $department)
                                        <option value="{{$department}}" @if(old('department') == $department) selected @endif>
                                            {{$department}}
                                        </option>
                                    @endforeach
                                </select>
                                @error('department')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                                @enderror
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="type">سنة التخرج</label>
                                <input type="date" name="graduation_date" value="{{old('graduation_date')}}" class="form-control @error('graduation_date') is-invalid @enderror" >
                                @error('graduation_date')
                                <div class="invalid-feedback">
                                    {{$message}}
                                </div>
                                @enderror
                            </div>

                        </div>

                        <button class="btn btn-primary" type="submit">{{__('backend.save')}}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
