@extends('layouts.master')

@section('content')
    <nav aria-label="breadcrumb" class="paths-nav">
        <ol class="breadcrumb breadcrumb-inverse">
            <li class="breadcrumb-item">
                <a href="{{route('home')}}">{{__('backend.home')}}</a>
            </li>
            <li class="breadcrumb-item">
                <a href="{{route('studies.index')}}">{{__('backend.studies')}}</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">{{__('backend.studies.index')}}</li>
        </ol>
    </nav>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom justify-content-between" >
                    <h2>التفاصيل</h2>
                    <a href="{{route('studies.create')}}" class="btn btn-sm btn-primary"><i class="mdi mdi-plus"></i> {{__('backend.studies.create')}}</a>
                </div>
                <div class="card-body">

                    @if($application)
                        <div class="form-row">
                            <div class="col-md-4 mb-3">
                                <label for="type">نوع المنحه / البعثة</label>
                                <select  id="type"  disabled class="form-control">
                                    @foreach($studies_type as $type)
                                        @if($application->study_type == $type['name'])
                                            <option disabled selected>{{$type['alias']}} </option>
                                            @break
                                        @endif
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="country">{{__('backend.country')}}</label>
                                <select  class="form-control" disabled>
                                    <option disabled selected>{{$application->country->name}}</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="university">الجامعات</label>
                                <select  class="form-control" disabled>
                                @foreach($universities as $university)
                                    @if($application->university == $university['name'])
                                        <option disabled selected>{{$university['alias']}} </option>
                                        @break
                                    @endif
                                @endforeach
                                </select>
                            </div>


                        </div>
                        <div class="form-row">
                            <div class="col-md-4 mb-3">
                                <label for="studies">{{__('backend.studies')}}</label>
                                <select  class="form-control" disabled>
                                    <option disabled selected>{{$application->study->alias}}</option>
                                </select>

                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="department">ثانوية عامة شعبة</label>
                                <select  id="department"   class="form-control" disabled>
                                    @foreach($departments as $department)
                                        @if($application->department == $department)
                                            <option disabled selected>{{$department}} </option>
                                            @break
                                        @endif
                                    @endforeach
                                </select>

                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="type">سنة التخرج</label>
                                <input type="text" disabled  value="{{\Carbon\Carbon::createFromDate($application->graduation)->format('m/d/Y')}}" class="form-control" >
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="type"> تاريخ الطلب</label>
                                <input type="text" disabled  value="{{$application->created_at->format('m/d/Y')}}" class="form-control" >
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="type">  حالة الطلب</label>
                                @if($application->status == 'approved')
                                    <input type="text" disabled  value="تمت الموافقة" class="form-control bg-success ">
                                @elseif($application->status == 'pending')
                                    <input type="text" disabled  value=" تحت المراجعة" class="form-control bg-primary text-white">
                                @else
                                    <input type="text" disabled  value="  تم رفض طلبك " class="form-control bg-danger text-white">
                                    @endif
                            </div>
                        </div>
                    @else
                        لم يتم التسجيل فى منح او بعثات من قبل
                    @endif

                </div>
            </div>
        </div>
    </div>

@endsection
