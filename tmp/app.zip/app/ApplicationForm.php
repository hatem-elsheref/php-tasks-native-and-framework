<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplicationForm extends Model
{
    protected $table='application_forms';
    protected $fillable=[
        'university',
        'department',
        'graduation',
        'user_id',
        'study_id',
        'country_id',
        'status',
        'study_type'];


    public function user(){
        return $this->belongsTo(User::class,'user_id','id');
    }
    public function study(){
        return $this->belongsTo(Studies::class,'study_id','id');
    }
    public function country(){
        return $this->belongsTo(Country::class,'country_id','id');
    }
}
