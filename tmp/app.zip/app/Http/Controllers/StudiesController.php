<?php

namespace App\Http\Controllers;

use App\ApplicationForm;
use App\Country;
use App\Studies;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class StudiesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
        if (auth()->user()->role == 'admin')
            return redirect()->route('home');


        $types=config('menah.types');
        $universities=config('menah.universities');
        $departments=config('menah.primary_school_departments');
        $application=ApplicationForm::with(['user','country','study'])->where('user_id',auth()->id())->first();
        $data=['studies_type'=>$types,'application'=>$application,'universities'=>$universities,'departments'=>$departments];
        return view('studies.index',$data);
    }

    private function prepareData(){
        $studies=Studies::all();
        $countries=Country::select('id','name')->get();
        $types=config('menah.types');
        $departments=config('menah.primary_school_departments');
        $universities=config('menah.universities');
        return ['studies'=>$studies,'studies_type'=>$types,'countries'=>$countries,'departments'=>$departments,'universities'=>$universities];
}

    public function create(){

        if (auth()->user()->role == 'admin')
            return redirect()->route('home');


        return view('studies.create',$this->prepareData());
    }

    public function store(Request $request){

        if (auth()->user()->role == 'admin')
            return redirect()->route('home');

        $types=collect(config('menah.types'))->pluck('name')->toArray();
        $universities=collect(config('menah.universities'))->pluck('name')->toArray();
        $departments=config('menah.primary_school_departments');

        $request->validate([
          'type'      =>['required',Rule::in($types)],
          'country'   =>[Rule::requiredIf($request->type == 'external'),Rule::exists('countries','id')],
          'university'=>[Rule::requiredIf($request->type == 'internal'),Rule::in($universities)],
          'studies'   =>['required',Rule::exists('studies','id')],
          'department'=>['required',Rule::in($departments)],
          'graduation_date'=>['required']
      ]);

        $forms=ApplicationForm::where('user_id',auth()->id())->count();
        if ($forms > 0){
            self::Fail('backend.fail','لا يمكن طلب منح او بعثات اخرى ');
            return redirect()->route('studies.index');
        }
        $validatedData=['status'=>'pending','department'=>$request->department,'study_id'=>$request->studies,'user_id'=>auth()->id()];
        if ($request->type == 'internal'){
            $validatedData['study_type']='internal';
            $validatedData['country_id']=auth()->user()->country->id;
            $validatedData['university']=$request->university;
        }else{
            $validatedData['study_type']='external';
            $validatedData['country_id']=$request->country;
            $validatedData['university']=null;
        }
        $validatedData['graduation']=date_format(date_create($request->graduation_date),'Y');

        $form=ApplicationForm::create($validatedData);
        ($form)?self::Success():self::Fail();
            return redirect()->route('studies.index');
    }
}
