<?php

namespace App\Http\Controllers;
use App\ApplicationForm;
use App\Jobs\SendingEmail;


class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        if (auth()->user()->role == 'student')
            return redirect()->route('studies.index');

        $pendingApplications=ApplicationForm::with(['user','country','study'])
            ->where('status','pending')->paginate(PAGINATION);

        $approvedApplications=ApplicationForm::with(['user','country','study'])
            ->where('status','approved')->paginate(PAGINATION);

        $canceledApplications=ApplicationForm::with(['user','country','study'])
            ->where('status','canceled')->paginate(PAGINATION);

        return view('home')->with('approved',$approvedApplications)->with('canceled',$canceledApplications)->with('pending',$pendingApplications);


    }

    public function destroy($id){
        if (auth()->user()->role == 'student')
            return redirect()->route('studies.index');

        $application=ApplicationForm::findOrFail($id);
        $application->delete();
        self::Success();
        return redirect()->route('home');
    }


    public function accept($id){
        if (auth()->user()->role == 'student')
            return redirect()->route('studies.index');

        $application=ApplicationForm::findOrFail($id);
        $application->status='approved';
        $application->save();

        SendingEmail::dispatch($application);

        self::Success();
        return redirect()->route('home');
    }


    public function refuse($id){
        if (auth()->user()->role == 'student')
            return redirect()->route('studies.index');

        $application=ApplicationForm::findOrFail($id);
        $application->status='canceled';
        $application->save();
        self::Success();
        return redirect()->route('home');
    }

}
