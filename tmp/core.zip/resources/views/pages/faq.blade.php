@extends('layouts.application')
@section('content')
    <div class="card-body">
        <span class="card-title">
         <h5>تحتوى هذه الصفحة على اجابات لمعظم الاستفسارات المطروحة</h5>
        </span>
        <hr>
            <h5 class="text-danger" style="margin-bottom: 25px">سؤال : ماهى امتيازات المنح الخارجية؟</h5>
            <span class="text-success">جواب : تختلف الامتيازات المقدمة من دولة الى اخرى حيث تشمل تغطية الرسوم الدراسية</span>
        <hr>
    </div>
@endsection
