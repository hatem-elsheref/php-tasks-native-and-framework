@extends('layouts.application')
@section('content')
    <div class="card-body">
        <span class="card-title ">
         <h5>للتواصل مع الموقع او الجهة المختصة بالوزارة </h5>
        </span>
        <hr>
       <div class="text-center" style="font-size: 20px">
           <bold>Website: </bold><span class="text-primary">http://www.mohe.gov.sd</span><br>
           <bold>Email: </bold><span class="">mohe@gov.sd</span><br>
           <bold>Tel: </bold><span class="">+249 183 43 43234</span>
       </div>
    </div>
@endsection
