@component('mail::message')
اهلا {{ $name }}
<br>
نود ابلاغكم انه تم قبول طلبك لمنحه / بعثة فى {{$type}}
شكرا,<br>
فريق تعليمى
@endcomponent
